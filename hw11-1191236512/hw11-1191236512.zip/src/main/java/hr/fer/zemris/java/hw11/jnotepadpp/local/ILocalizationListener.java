package hr.fer.zemris.java.hw11.jnotepadpp.local;

public interface ILocalizationListener {
	void localizationChanged();
}
